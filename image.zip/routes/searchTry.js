var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  console.log('라우터 실행');
  var tagArray = new Array();
  tagArray.push(req.query.search);
  console.log('GET Parameter = ' + tagArray);

  var len = tagArray.length;
  var latestTag = tagArray[len - 1];

  res.send({latestTag : latestTag});
})
module.exports = router;
