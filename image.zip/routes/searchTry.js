var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  console.log('라우터 실행');
  var tagArray = req.query.search
  var tagstrarray

  for (i=0; i<tagArray.length; i++) {
    var tagstr = '{' + tagArray[i].tag + ' ' + tagArray[i].upload + '}, ' ;
    tagstrarray += tagstr;
  }
  console.log('GET Parameter = ' + tagstrarray);
})
module.exports = router;
