//var tagArray = tag_from_server;

$(document).ready(function() {
    var aTag;

    $("input[name=search]").keydown(function (key) {
        if(key.keyCode == 13) {

            aTag = $(".searchbox").val();

            $.ajax({
              url : '/search',
              type : 'GET',
              dataType : 'json',
              data : {
                'search' : aTag
              },
              success : makeTagContainer($('#tagbox'), aTag)
            });

            $("input").val('');
            return false;

            /*makeTagContainer($('#tagbox'), aTag);
            return false;*/
        }
    });

    $('#tagbox').on("click", ".close", function(e) {
        deleteTagContainer(e);
    });
});

function makeTagContainer(target_div, aTag) {
    var tag = aTag;
    var $target = target_div;
    var $container = $("<div></div>");
    var $close = makeCloseButton();

    $container.text(tag);
    $container.append($close);
    $target.append($container);

    return $target.children().length;
}

function makeCloseButton() {
    var $closebt = $("<div>X</div>");
    $closebt.addClass('close');

    return $closebt;
}

function deleteTagContainer(e) {
    var $target = $(e.target);

    $target.parent().remove();
}
